# FLASK-RRTConnect：六个 DynoBench 场景

独立 C++17 / Eigen / yaml-cpp 工程。目标仅为截图第一列：DF + 双向 RRTConnect，运行 Unicycle Bugtrap/Wall、Quad2D Bugtrap/Hole、Quad3D Block/Window。目录名称沿用最初理论验证任务；不继续扩展 SST、DP-RRT、机械臂或对比算法。

2026-10-12历史版本：CTest **19/19**，六场景seed41/42/43共 **18/18** 规划成功。实际轨迹和统计在 `results/rrtconnect_six_final_20261012`，不代表当前版本结果。当前 CTest 注册20项，其中6项六场景基准显式禁用，正常测试应为14项；禁用项不计作通过。

Linux 首次运行先安装 `build-essential cmake libeigen3-dev libyaml-cpp-dev python3 python3-matplotlib`。然后生成当前六场景配置（r=2、R=I、rho=1、shortcut开启）；脚本只改根 examples 配置，不改历史实验快照：

```sh
python3 tools/configure_six.py
cmake -S . -B build-linux -DCMAKE_BUILD_TYPE=Release -DFLASK_ENABLE_AVX2=ON
cmake --build build-linux --parallel 2
ctest --test-dir build-linux --output-on-failure
python3 tools/benchmark.py --executable build-linux/flask_plan --output results/six_run --seeds 20
python3 tools/summarize_runs.py results/six_run
/usr/bin/python3 -I tools/plot_six.py results/six_run
```

若Unicycle日志出现 `Pose-speed sampling is not part of this paper profile`，说明根examples仍含旧的固定速度采样配置，尚未进入规划；重新运行当前 `tools/configure_six.py`。当前仓库的六份根配置已同步生成，无该字段，均为R=I、rho=1、shortcut开启。配置更新不需重新编译；已有results下的实验快照保留。

Ubuntu若混用 `~/.local` 和 `/usr/lib/python3/dist-packages` 的Matplotlib，可能出现 `cannot import name docstring` 或无法导入Axes3D。使用上面的系统解释器和 `-I` 隔离用户site-packages，不需要卸载其他项目的Python包。生成图片成功后再运行 `xdg-open results/six_run/paths.png`。

Windows 可执行文件后缀为 `.exe`；多配置生成器可能位于构建目录的 `Release` 子目录。输出目录必须不存在。脚本默认运行全部六场景，每场内部预算10秒、进程上限15秒，真实记录失败，不换规划器。直接运行单场景：

重复计时支持 `tools/benchmark.py --repeats 20`：对指定的每个seed/场景启动20个独立进程，文件名附加重复序号，全部原始记录保留。执行完后用 `python3 tools/summarize_runs.py <结果目录>` 生成首解时间、含shortcut总时间、cost和长度的均值/样本标准差，以及成功率和单独的失败耗时。默认仍为每seed一次。固定seed重复仅测量同一随机序列的耗时波动，不是不同seed的采样成功率实验；独立seed实验可传 `--seeds $(seq 20 39)`。`plot_six.py` 适用于每个seed一次的结果，只画第一个seed；不支持把同一seed的20轮重复全部画入六子图。

```sh
build-linux/flask_plan examples/dynobench_quad3d_window.yaml window.yaml 20
```

离线依赖可指定 `FLASK_EIGEN_SOURCE` 和 `FLASK_YAML_SOURCE`，默认不下载。冻结内核在 `vendor/rrtpff`，数据来源/哈希在 `examples/dynobench_data/SOURCE_MANIFEST.json`。不修改相邻 RRT*/PFF 工程与原始数据。

搜索使用 extent 加权 nearest-neighbor、BVP 时间分数插值、两棵树正时间边、connect循环和BVP shortcut。metric/interpolation 对照作者公开 [OMPL port](https://github.com/ompl/ompl/pull/1472)，不是 Eq.33 的 cost neighborhood；range=.25是本地配置，无rewiring，无渐近最优性声明。

目标树截短是本地kinodynamic适配：在 `target→parent` 的incoming BVP上取末段起点；start树取outgoing BVP前段。公开几何port两棵树均用 `parent→target` 插值，不能把本修正误写成作者私有实验默认策略。Unicycle r2额外检查四次速度模平方的所有极值，拒绝网格之间的零速和速度超限；omega和其他物理约束仍按有限采样检查。

六场景均采用 r=2、rho=1。Unicycle固定非零正向速度分支，端点lift显式给出。Quad节点只固定位置/速度（Quad3D另有yaw/yaw rate）；每条cubic从高阶导数恢复物理状态和控制并做采样限幅。配置明确关闭两个高阶检查：`enforce_physical_endpoints: false`、`enforce_physical_continuity: false`，实际端点和拼接误差写入结果。r2不能保证完整姿态/omega连续。通用full-state r4仍可显式选择，默认严格检查，但不再用作六场景配置。

当前搜索使用flat box均匀采样。旧的 `planner.unicycle_sample_speed>0` 固定速度pose采样已移除，读取旧配置时会报错；请运行配置生成脚本更新根examples。Unicycle端点速度仍由显式lifting指定。历史结果快照里的pose采样不代表当前策略。

生成后的六场景按用户指定均使用Eq.20的 `R=I`、rho=1；旧实验中的Unicycle `R=10I`保留在历史快照。range、bounds、球覆盖和预算等本地参数均显式给出，不声称是作者未公开的默认参数。

几何采用单球机器人和box保守球覆盖，半径/cell显式配置，不冒充作者默认值。生成后的六场景使用Algorithm 3有限采样，额外的Bernstein连续球几何检查关闭；可通过配置显式开启。Algorithm 3可能漏检薄障碍；连续几何检查也不等于完整控制证书。

批量验证为AVX2 double4x2，包含jet、DF逆映射、物理约束和碰撞。普通/AVX2编译单元统一Eigen对齐到16字节，AVX显式加载使用unaligned指令；不需要对整个程序添加 `-mavx2`。不支持AVX2的CPU由Validator选择标量路径。终点时间按 `T*(i/intervals)` 构造，严格保留非法时间拒绝检查。

输出：

- `runs.csv` / `summary.md`：成功率、轨迹长度(m)、规划时间(ms)、搜索时间、cost、失败原因。长度积分平移速度模长，不含yaw，不是BVP cost。规划时间包含shortcut，排除进程启动、长度求积和I/O。
- `manifest.json`：本轮二进制、配置、核心源码、runner的SHA-256与运行平台，便于核对结果来源。
- `*_41.yaml`：精确分段多项式、物理样本、输入快照、物理端点/拼接误差。
- `*_41.dynobench.yaml`：`result: [{states, actions}]` 可视化布局，按模型dt采样，末步可能不足dt。不是零阶保持积分输出，明确标记 `dynobench_checker_verified: false`。

本项目读取 DynoBench 数据运行独立规划器，未链接官方DynoBench/FCL runtime。原生动力学checker通过目前尚未达成，不能用“文件格式可读”替代。

审查见 [paper_implementation_status.md](docs/paper_implementation_status.md)，本轮实测见 [rrtconnect_six_review.md](docs/rrtconnect_six_review.md)。之前要求的三个理论测试和 [Theory-to-Code Matrix](docs/theoretical_guarantees.md) 保留为审计材料。历史实验输出保留，不代表当前版本结果。
